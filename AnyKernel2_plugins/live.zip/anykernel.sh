# AnyKernel2 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() {
kernel.string=Venom Livedisplay Plug-in by tanish2k09
do.devicecheck=1
do.cleanup=1
do.cleanuponabort=0
device.name1=aio_row
device.name2=A7000
device.name3=A7000-a
device.name4=
device.name5=
do.system=1
} # end properties